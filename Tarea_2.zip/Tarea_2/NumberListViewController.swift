

import UIKit

class NumberListViewController: UIViewController {
    
@IBOutlet weak var tableView: UITableView!
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
   
    }
    override func viewWillAppear(_ animated: Bool) {
           super.viewDidAppear(animated)
       }
   
        
    }

