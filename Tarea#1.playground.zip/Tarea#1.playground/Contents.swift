import UIKit

//  ejer 1
var array = [String](repeating: "dog", count: 3)

//  ejer 2
var intnumero = 0
for num in 0...intnumero {
   
    if num % 2 == 0 {
        print ("\(num) par!!!")
    }else {
        print ("\(num) impar!!!")
    }
}


//  ejer 3
let num1: String = "carro"
let num2: String = "hola"

let caracteres1: Int = num1.count
let caracteres2: Int = num2.count
if caracteres1 > caracteres2 {
    print(num1)}
else  {
    print(num2);
}


// ejer 4
func fibonacciRecursiveNum1(num1: Int, num2: Int, steps: Int) {

    if steps > 0 {
        let newNum = num1 + num2
        fibonacciRecursiveNum1(num1: num2, num2: newNum, steps: steps-1)
    }
    else {
        print("true")
    }
}

